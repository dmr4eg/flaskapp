## Miniproject 1
commit - d06782ae41046015c486a13a56b574f1e88152a0
url - https://gitlab.fel.cvut.cz/assyldam/nsi/-/tree/miniproject1?ref_type=heads