# Miniproject 2

commit - f4773da735e37061de446d1f5aad92a55baa69d8
url - https://gitlab.fel.cvut.cz/assyldam/nsi/-/tree/miniproject2?ref_type=heads